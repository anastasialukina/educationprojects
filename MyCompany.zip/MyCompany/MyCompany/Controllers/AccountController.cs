﻿using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using MyCompany.Domain;
using MyCompany.Models;

namespace MyCompany.Controllers
{
    [Authorize]
    public class AccountController : Controller
    {
        private readonly UserManager<IdentityUser> userManager;
        private readonly SignInManager<IdentityUser> signInManager;

        private readonly string[] allowedRoles = {AppDbContext.CustomerRole, AppDbContext.ExecutorRole};

        public AccountController(UserManager<IdentityUser> userMgr, SignInManager<IdentityUser> signinMgr)
        {
            userManager = userMgr;
            signInManager = signinMgr;
        }

        [AllowAnonymous]
        public IActionResult Login(string returnUrl)
        {
            ViewBag.returnUrl = returnUrl;
            return View(new LoginViewModel());
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> Login(LoginViewModel model, string returnUrl)
        {
            if (ModelState.IsValid)
            {
                IdentityUser user = await userManager.FindByNameAsync(model.UserName);

                if (user != null)
                {
                    await signInManager.SignOutAsync();
                    var result =
                        await signInManager.PasswordSignInAsync(user, model.Password, model.RememberMe, false);
                    if (result.Succeeded)
                    {
                        if (await userManager.IsInRoleAsync(user, AppDbContext.CustomerRole))
                        {
                            return Redirect("/Customer");
                        }

                        if (await userManager.IsInRoleAsync(user, AppDbContext.ExecutorRole))
                        {
                            return Redirect("/Executor");
                        }

                        return Redirect(returnUrl ?? "/");
                    }
                }

                ModelState.AddModelError(nameof(LoginViewModel.UserName), "Неверный логин или пароль");
            }

            return View(model);
        }

        [AllowAnonymous]
        public IActionResult Register()
        {
            return View(new RegisterViewModel());
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (!allowedRoles.Contains(model.DesiredRole))
            {
                ModelState.AddModelError("error", "Некорректная роль");
                return View(model);
            }

            var user = new IdentityUser
            {
                UserName = model.UserName,
                Email = model.Email,
                EmailConfirmed = true,
                SecurityStamp = string.Empty,
            };

            var userCreating = await userManager.CreateAsync(user, model.Password);
            if (!userCreating.Succeeded)
            {
                ModelState.AddModelError("error", userCreating.ToString());
                return View(model);
            }


            var roleAssigning = await userManager.AddToRoleAsync(user, model.DesiredRole);
            if (!roleAssigning.Succeeded)
            {
                ModelState.AddModelError("error", "Не удалось назначить роль пользователю");
                return View(model);
            }

            return Redirect("/Account/Login");
        }

        [Authorize]
        public async Task<IActionResult> Logout()
        {
            await signInManager.SignOutAsync();
            return RedirectToAction("Index", "Home");
        }
    }
}