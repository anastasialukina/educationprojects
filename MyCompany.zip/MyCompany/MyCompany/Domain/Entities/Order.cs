﻿using System;
using System.ComponentModel.DataAnnotations;


namespace MyCompany.Domain.Entities
{
    public class Order: EntityBase
    {
        [Required(ErrorMessage = "Заполните название заказа")]
        [Display(Name = "Название заказа")]
        public override string Title { get; set; }

        [Display(Name = "Описание заказа")]
        public override string Subtitle { get; set; }

        [Display(Name = "Текст выполненного заказа")]
        public override string Text { get; set; }

        [Display(Name = "Статус заказа")]
        public OrderStatus Status { get; set; }

        public Guid ExecutorId { get; set; }
        public Guid CustomerId { get; set; }

        
        
    }
}
