﻿
namespace MyCompany.Domain.Entities
{
    public enum OrderStatus
    {
        Created, 
        ReadyForReview, 
        Done, 
    }
}
