﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace MyCompany.Migrations
{
    public partial class AddToOrder : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "44546e06-8719-4ad8-b88a-f271ae9d6eab",
                column: "ConcurrencyStamp",
                value: "159c7b83-84af-495f-99bb-b3905ec9b52a");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "60add60b-637d-4d50-acd3-f45906df8ecf",
                column: "ConcurrencyStamp",
                value: "71780ea5-d7e0-4a91-9a48-9f8ee9e2f07b");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "b95e0725-5c2f-40a6-bc61-e5d6989305f9",
                column: "ConcurrencyStamp",
                value: "f7436487-cbf9-4863-8161-211ad3ade282");

            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "3b62472e-4f66-49fa-a20f-e7685b9565d8",
                columns: new[] { "ConcurrencyStamp", "PasswordHash" },
                values: new object[] { "63f15d70-de1d-4b5c-85a1-406c0e4d6f14", "AQAAAAEAACcQAAAAEMRKusae28/nJI2ZWCCu07y1AWzYz2HBILtIDIX/ySyo2ppAbkwpO7JmmtbSCQp2Tg==" });

            migrationBuilder.UpdateData(
                table: "TextFields",
                keyColumn: "Id",
                keyValue: new Guid("4aa76a4c-c59d-409a-84c1-06e6487a137a"),
                column: "DateAdded",
                value: new DateTime(2021, 12, 19, 14, 16, 20, 27, DateTimeKind.Utc).AddTicks(7229));

            migrationBuilder.UpdateData(
                table: "TextFields",
                keyColumn: "Id",
                keyValue: new Guid("63dc8fa6-07ae-4391-8916-e057f71239ce"),
                column: "DateAdded",
                value: new DateTime(2021, 12, 19, 14, 16, 20, 27, DateTimeKind.Utc).AddTicks(3597));

            migrationBuilder.UpdateData(
                table: "TextFields",
                keyColumn: "Id",
                keyValue: new Guid("70bf165a-700a-4156-91c0-e83fce0a277f"),
                column: "DateAdded",
                value: new DateTime(2021, 12, 19, 14, 16, 20, 27, DateTimeKind.Utc).AddTicks(7163));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "44546e06-8719-4ad8-b88a-f271ae9d6eab",
                column: "ConcurrencyStamp",
                value: "ca6e34f3-dade-4637-805b-bc00bfd1281d");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "60add60b-637d-4d50-acd3-f45906df8ecf",
                column: "ConcurrencyStamp",
                value: "e8924214-d1bc-4e32-972f-388d0614d6ae");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "b95e0725-5c2f-40a6-bc61-e5d6989305f9",
                column: "ConcurrencyStamp",
                value: "6dc33276-8eb7-458e-bf43-9f657a29e2f7");

            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "3b62472e-4f66-49fa-a20f-e7685b9565d8",
                columns: new[] { "ConcurrencyStamp", "PasswordHash" },
                values: new object[] { "959e7b54-97e0-47b7-9575-3fc2e420f408", "AQAAAAEAACcQAAAAEAFrXyAonG0JnYvpEm8d1kVO2st+NWny7fB4FRvKhrNDdHPsGRnNUBZKxUqVMV/7qA==" });

            migrationBuilder.UpdateData(
                table: "TextFields",
                keyColumn: "Id",
                keyValue: new Guid("4aa76a4c-c59d-409a-84c1-06e6487a137a"),
                column: "DateAdded",
                value: new DateTime(2021, 12, 19, 12, 44, 50, 626, DateTimeKind.Utc).AddTicks(8108));

            migrationBuilder.UpdateData(
                table: "TextFields",
                keyColumn: "Id",
                keyValue: new Guid("63dc8fa6-07ae-4391-8916-e057f71239ce"),
                column: "DateAdded",
                value: new DateTime(2021, 12, 19, 12, 44, 50, 626, DateTimeKind.Utc).AddTicks(5181));

            migrationBuilder.UpdateData(
                table: "TextFields",
                keyColumn: "Id",
                keyValue: new Guid("70bf165a-700a-4156-91c0-e83fce0a277f"),
                column: "DateAdded",
                value: new DateTime(2021, 12, 19, 12, 44, 50, 626, DateTimeKind.Utc).AddTicks(8061));
        }
    }
}
