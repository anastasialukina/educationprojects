﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace MyCompany.Migrations
{
    public partial class AddToOrderMigra : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<Guid>(
                name: "CustomerId",
                table: "Orders",
                type: "TEXT",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddColumn<Guid>(
                name: "ExecutorId",
                table: "Orders",
                type: "TEXT",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "44546e06-8719-4ad8-b88a-f271ae9d6eab",
                column: "ConcurrencyStamp",
                value: "d525507d-8b2f-4243-bf34-ed12441e0ffb");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "60add60b-637d-4d50-acd3-f45906df8ecf",
                column: "ConcurrencyStamp",
                value: "a20e48a1-e935-4474-a7cf-79b4b0e298b9");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "b95e0725-5c2f-40a6-bc61-e5d6989305f9",
                column: "ConcurrencyStamp",
                value: "8be1ca22-285c-4d0d-88c3-e24352beb98c");

            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "3b62472e-4f66-49fa-a20f-e7685b9565d8",
                columns: new[] { "ConcurrencyStamp", "PasswordHash" },
                values: new object[] { "64480348-65ac-4b93-be30-6c509e813c86", "AQAAAAEAACcQAAAAEO+Oe1GCc5BQfX97XO8UfH+5dHDaKdNGBGjgpH5iPXy7QWhE+7ItLarY0lTl/qnGRg==" });

            migrationBuilder.UpdateData(
                table: "TextFields",
                keyColumn: "Id",
                keyValue: new Guid("4aa76a4c-c59d-409a-84c1-06e6487a137a"),
                column: "DateAdded",
                value: new DateTime(2021, 12, 19, 14, 20, 29, 307, DateTimeKind.Utc).AddTicks(6741));

            migrationBuilder.UpdateData(
                table: "TextFields",
                keyColumn: "Id",
                keyValue: new Guid("63dc8fa6-07ae-4391-8916-e057f71239ce"),
                column: "DateAdded",
                value: new DateTime(2021, 12, 19, 14, 20, 29, 307, DateTimeKind.Utc).AddTicks(4005));

            migrationBuilder.UpdateData(
                table: "TextFields",
                keyColumn: "Id",
                keyValue: new Guid("70bf165a-700a-4156-91c0-e83fce0a277f"),
                column: "DateAdded",
                value: new DateTime(2021, 12, 19, 14, 20, 29, 307, DateTimeKind.Utc).AddTicks(6685));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "CustomerId",
                table: "Orders");

            migrationBuilder.DropColumn(
                name: "ExecutorId",
                table: "Orders");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "44546e06-8719-4ad8-b88a-f271ae9d6eab",
                column: "ConcurrencyStamp",
                value: "159c7b83-84af-495f-99bb-b3905ec9b52a");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "60add60b-637d-4d50-acd3-f45906df8ecf",
                column: "ConcurrencyStamp",
                value: "71780ea5-d7e0-4a91-9a48-9f8ee9e2f07b");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "b95e0725-5c2f-40a6-bc61-e5d6989305f9",
                column: "ConcurrencyStamp",
                value: "f7436487-cbf9-4863-8161-211ad3ade282");

            migrationBuilder.UpdateData(
                table: "AspNetUsers",
                keyColumn: "Id",
                keyValue: "3b62472e-4f66-49fa-a20f-e7685b9565d8",
                columns: new[] { "ConcurrencyStamp", "PasswordHash" },
                values: new object[] { "63f15d70-de1d-4b5c-85a1-406c0e4d6f14", "AQAAAAEAACcQAAAAEMRKusae28/nJI2ZWCCu07y1AWzYz2HBILtIDIX/ySyo2ppAbkwpO7JmmtbSCQp2Tg==" });

            migrationBuilder.UpdateData(
                table: "TextFields",
                keyColumn: "Id",
                keyValue: new Guid("4aa76a4c-c59d-409a-84c1-06e6487a137a"),
                column: "DateAdded",
                value: new DateTime(2021, 12, 19, 14, 16, 20, 27, DateTimeKind.Utc).AddTicks(7229));

            migrationBuilder.UpdateData(
                table: "TextFields",
                keyColumn: "Id",
                keyValue: new Guid("63dc8fa6-07ae-4391-8916-e057f71239ce"),
                column: "DateAdded",
                value: new DateTime(2021, 12, 19, 14, 16, 20, 27, DateTimeKind.Utc).AddTicks(3597));

            migrationBuilder.UpdateData(
                table: "TextFields",
                keyColumn: "Id",
                keyValue: new Guid("70bf165a-700a-4156-91c0-e83fce0a277f"),
                column: "DateAdded",
                value: new DateTime(2021, 12, 19, 14, 16, 20, 27, DateTimeKind.Utc).AddTicks(7163));
        }
    }
}
