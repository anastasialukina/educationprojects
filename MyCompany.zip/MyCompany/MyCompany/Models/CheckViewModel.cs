﻿using System.ComponentModel.DataAnnotations;

namespace MyCompany.Models
{
    public class CheckViewModel
    {
        //[Required]
    };
}
